﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StudentWindow
{
    /// <summary>
    /// Interaction logic for Student_Information.xaml
    /// </summary>
    public partial class Student_Information : Window
    {
        public Student_Information()
        {
            InitializeComponent();
        }

        private void btnchangepass_Click(object sender, RoutedEventArgs e)
        {
            if (!Application.Current.Windows.OfType<Student_ChangePassword>().Any())
            {
                Student_ChangePassword change = new Student_ChangePassword();
                change.Show();
            }
        }
    }
}
